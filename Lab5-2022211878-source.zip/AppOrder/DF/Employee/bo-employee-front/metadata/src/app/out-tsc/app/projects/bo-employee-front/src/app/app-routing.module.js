import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
var routes = [
    { path: 'BookList', loadChildren: './booklist/booklist#BookListModule' },
    { path: 'BookForm', loadChildren: './bookform/bookform#BookFormModule' },
    { path: 'ReaderForm', loadChildren: './readerform/readerform#ReaderFormModule' },
    { path: 'ReaderList', loadChildren: './readerlist/readerlist#ReaderListModule' },
    { path: 'BorrowingRecordsList', loadChildren: './borrowingrecordslist/borrowingrecordslist#BorrowingRecordsListModule' },
    { path: 'BorrowingRecordsFrom', loadChildren: './borrowingrecordsfrom/borrowingrecordsfrom#BorrowingRecordsFromModule' }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib_1.__decorate([
        NgModule({
            imports: [RouterModule.forRoot(routes, { useHash: true })],
            exports: [RouterModule]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());
export { AppRoutingModule };
