import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { BookEntity } from './entities/bookentity';
import { BookProxy } from './bookproxy';
var BookRepository = /** @class */ (function (_super) {
    tslib_1.__extends(BookRepository, _super);
    function BookRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'BookRepository';
        _this.paginationInfo = {};
        _this.proxy = injector.get(BookProxy, null);
        return _this;
    }
    BookRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/apporder/df/v1.0/book_frm',
            entityType: BookEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], BookRepository);
    return BookRepository;
}(BefRepository));
export { BookRepository };
