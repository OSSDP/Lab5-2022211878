import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'version_c1e790e2_new3',
            name: "{{version_c1e790e2_new3}}",
            binding: 'version',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '版本',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "version", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'name_be9fdd20_s8qa',
            name: "{{name_be9fdd20_s8qa}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '书名',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'author_14f27755_bzi8',
            name: "{{author_14f27755_bzi8}}",
            binding: 'author',
            updateOn: 'blur',
            defaultI18nValue: '作者',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "author", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'publishing_house_2f9b85c0_s37t',
            name: "{{publishing_house_2f9b85c0_s37t}}",
            binding: 'publishing_house',
            updateOn: 'blur',
            defaultI18nValue: '出版社',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "publishing_house", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'publication_date_9359d337_sclm',
            name: "{{publication_date_9359d337_sclm}}",
            binding: 'publication_date',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '出版日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "publication_date", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'bstatus_5dfb9061_xyqe',
            name: "{{bstatus_5dfb9061_xyqe}}",
            binding: 'bstatus',
            updateOn: 'change',
            defaultI18nValue: '状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "bstatus", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '图书',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
