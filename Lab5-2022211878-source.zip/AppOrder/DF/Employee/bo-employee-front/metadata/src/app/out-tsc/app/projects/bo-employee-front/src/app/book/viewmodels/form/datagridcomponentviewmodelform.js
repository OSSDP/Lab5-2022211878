import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'version',
            name: "{{version_0d632a6a_2erx}}",
            binding: 'version',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '版本',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "version", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'name',
            name: "{{name_8a726937_e7m8}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '书名',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'author',
            name: "{{author_8d1c46ea_79t5}}",
            binding: 'author',
            updateOn: 'blur',
            defaultI18nValue: '作者',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "author", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'publishing_house',
            name: "{{publishing_house_dba67398_xhui}}",
            binding: 'publishing_house',
            updateOn: 'blur',
            defaultI18nValue: '出版社',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "publishing_house", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'publication_date',
            name: "{{publication_date_1c5f5b53_4ug9}}",
            binding: 'publication_date',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '出版日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "publication_date", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'bstatus',
            name: "{{bstatus_bb02a20a_4nol}}",
            binding: 'bstatus',
            updateOn: 'blur',
            defaultI18nValue: '状态(0 下架, 1 正常)',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "bstatus", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '图书',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
