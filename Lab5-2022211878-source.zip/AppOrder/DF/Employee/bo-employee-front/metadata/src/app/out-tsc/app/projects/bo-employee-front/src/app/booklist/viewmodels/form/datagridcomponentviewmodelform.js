import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'version',
            name: "{{version_7b6831d5_47tt}}",
            binding: 'version',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '版本',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "version", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'name',
            name: "{{name_87cf6992_u75b}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '书名',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'author',
            name: "{{author_3bc61b00_ngxd}}",
            binding: 'author',
            updateOn: 'blur',
            defaultI18nValue: '作者',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "author", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'publishing_house',
            name: "{{publishing_house_56cc51a8_0zg7}}",
            binding: 'publishing_house',
            updateOn: 'blur',
            defaultI18nValue: '出版社',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "publishing_house", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'publication_date',
            name: "{{publication_date_2592120e_5yvq}}",
            binding: 'publication_date',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '出版日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "publication_date", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'bstatus',
            name: "{{bstatus_91dd7c9a_mqe1}}",
            binding: 'bstatus',
            updateOn: 'change',
            defaultI18nValue: '状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "bstatus", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '图书',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
