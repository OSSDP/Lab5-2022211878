import * as tslib_1 from "tslib";
import { Component, Injector, ViewChild, HostBinding, ElementRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Form, FrameComponent, FARRIS_DEVKIT_FRAME_PROVIDERS, ViewModel, FRAME_ID, BindingData, Repository, UIState, EXCEPTION_HANDLER, NAMESPACE } from '@farris/devkit';
import { FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS, ComponentManagerService } from '@farris/command-services';
import { KeybindingService } from '@farris/command-services';
import { ActivatedRoute, Router } from '@angular/router';
import { FrmI18nSettingService } from '@gsp-sys/rtf-common';
import { DomSanitizer } from '@angular/platform-browser';
import { FocusInvalidService } from '@farris/command-services';
import { LookupGridComponent } from '@farris/ui-lookup';
import { BefLookupRestService, DefaultComboHttpService } from '@farris/bef';
import { ServerSideToken } from '@farris/ui-lookup';
import { ComboServerSideToken } from '@farris/ui-combo-list';
import { WizardService } from '@farris/ui-wizard';
import { LocalizationService } from "@farris/command-services";
import { BasicFormViewmodel } from '../../viewmodels/basicformviewmodel';
import { BorrowingRecordsRepository } from '../../models/borrowingrecordsrepository';
import { LangService } from '../../lang/lang-pipe';
import { BasicFormViewmodelForm } from '../../viewmodels/form/basicformviewmodelform';
import { BasicFormViewmodelUIState } from '../../viewmodels/uistate/basicformviewmodeluistate';
var BasicFormComponent = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormComponent, _super);
    function BasicFormComponent(wizardSer, keybindingService, langService, route, router, rootElement, localizationService, frmI18nSettingService, focusInvalidService, componentManagerService, sanitizer, injector) {
        var _this = _super.call(this, injector) || this;
        _this.wizardSer = wizardSer;
        _this.keybindingService = keybindingService;
        _this.langService = langService;
        _this.route = route;
        _this.router = router;
        _this.rootElement = rootElement;
        _this.localizationService = localizationService;
        _this.frmI18nSettingService = frmI18nSettingService;
        _this.focusInvalidService = focusInvalidService;
        _this.componentManagerService = componentManagerService;
        _this.sanitizer = sanitizer;
        _this.injector = injector;
        _this.cls = 'f-struct-wrapper ';
        _this.lang = "";
        _this.size = {};
        _this.enabledLanguageList = [];
        _this.tabsToolbarStates = new BehaviorSubject({});
        _this.tabsToolbarVisibleStates = new BehaviorSubject({});
        _this.SectionbasicformsectionMainTitle = _this.langService.transform('Section/basic-form-section/mainTitle', _this.lang, "基本信息");
        _this.SectionbasicformsectionSubTitle = _this.langService.transform('Section/basic-form-section/subTitle', _this.lang, "");
        _this.LookupEditreaderidcd38ce3fs96vDialogTitle = _this.langService.transform('LookupEdit/reader_id_cd38ce3f_s96v/dialogTitle', _this.lang, "");
        _this.reader_id_cd38ce3f_s96v_PlaceHolder = _this.langService.transform('LookupEdit/reader_id_cd38ce3f_s96v/placeHolder', _this.lang, "");
        _this.LookupEditreaderidreaderidnameca4337cbt47lDialogTitle = _this.langService.transform('LookupEdit/reader_id_reader_id_name_ca4337cb_t47l/dialogTitle', _this.lang, "");
        _this.reader_id_reader_id_name_ca4337cb_t47l_PlaceHolder = _this.langService.transform('LookupEdit/reader_id_reader_id_name_ca4337cb_t47l/placeHolder', _this.lang, "");
        _this.LookupEditbookid92f531b74hnlDialogTitle = _this.langService.transform('LookupEdit/book_id_92f531b7_4hnl/dialogTitle', _this.lang, "");
        _this.book_id_92f531b7_4hnl_PlaceHolder = _this.langService.transform('LookupEdit/book_id_92f531b7_4hnl/placeHolder', _this.lang, "");
        _this.LookupEditbookidbookidname54e83f87yufcDialogTitle = _this.langService.transform('LookupEdit/book_id_book_id_name_54e83f87_yufc/dialogTitle', _this.lang, "");
        _this.book_id_book_id_name_54e83f87_yufc_PlaceHolder = _this.langService.transform('LookupEdit/book_id_book_id_name_54e83f87_yufc/placeHolder', _this.lang, "");
        _this.version_7562dd01_rjne_PlaceHolder = _this.langService.transform('DateBox/version_7562dd01_rjne/placeHolder', _this.lang, "");
        _this.borrow_date_65e8e886_bmex_PlaceHolder = _this.langService.transform('DateBox/borrow_date_65e8e886_bmex/placeHolder', _this.lang, "");
        _this.due_date_b0270f3d_wrh1_PlaceHolder = _this.langService.transform('DateBox/due_date_b0270f3d_wrh1/placeHolder', _this.lang, "");
        _this.return_date_ff65912b_izvj_PlaceHolder = _this.langService.transform('DateBox/return_date_ff65912b_izvj/placeHolder', _this.lang, "");
        _this.rstatus_3d04cde5_waebEnumData = [
            {
                "name": _this.langService.transform('EnumField/rstatus_3d04cde5_waeb/enumData/1', _this.lang, "借出"),
                "value": "1"
            },
            {
                "name": _this.langService.transform('EnumField/rstatus_3d04cde5_waeb/enumData/2', _this.lang, "已归还"),
                "value": "2"
            },
            {
                "name": _this.langService.transform('EnumField/rstatus_3d04cde5_waeb/enumData/3', _this.lang, "逾期"),
                "value": "3"
            }
        ];
        _this.rstatus_3d04cde5_waeb_PlaceHolder = _this.langService.transform('EnumField/rstatus_3d04cde5_waeb/placeHolder', _this.lang, "");
        _this.notes_494b4a5e_5w9n_PlaceHolder = _this.langService.transform('TextBox/notes_494b4a5e_5w9n/placeHolder', _this.lang, "");
        _this.lang = localStorage.getItem('languageCode') || "zh-CHS";
        _this.viewModel.verifycationChanged.subscribe(function (verifyInformations) {
            _this.focusInvalidService.focusInvalidInput(verifyInformations, _this.rootElement);
        });
        if (_this.frmI18nSettingService) {
            var i18nSetting = _this.frmI18nSettingService.getSetting();
            if (i18nSetting && i18nSetting.languages && i18nSetting.languages.length > 0) {
                i18nSetting.languages.forEach(function (item) {
                    _this.enabledLanguageList.push({
                        code: item.code,
                        name: item.name
                    });
                });
            }
            else {
                console.warn("get current enable languages is null. if this occurs,please ensure the form into the framework.");
                _this.enabledLanguageList.push({ "code": "en", "name": "English" });
                _this.enabledLanguageList.push({ "code": "zh-CHS", "name": "中文简体" });
            }
        }
        return _this;
    }
    BasicFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.keybindingService) {
            this.viewModel.keybindingMap.forEach(function (keyBinding, method) {
                _this.keybindingService.register(keyBinding, function () {
                    return _this.viewModel[method]();
                });
            });
        }
        this.onFormLoad();
    };
    BasicFormComponent.prototype.ngAfterViewInit = function () {
        this.componentManagerService.appendControl('reader_id_cd38ce3f_s96v', this.reader_id_cd38ce3f_s96v);
        this.componentManagerService.appendControl('reader_id_reader_id_name_ca4337cb_t47l', this.reader_id_reader_id_name_ca4337cb_t47l);
        this.componentManagerService.appendControl('book_id_92f531b7_4hnl', this.book_id_92f531b7_4hnl);
        this.componentManagerService.appendControl('book_id_book_id_name_54e83f87_yufc', this.book_id_book_id_name_54e83f87_yufc);
    };
    BasicFormComponent.prototype.ngOnDestroy = function () {
        // 增加表单的自我销毁
        this.context.dispose && this.context.dispose();
        this.viewModel = null;
        this.context = null;
        this.subscription = null;
        this.declaration = null;
        this.wizardSer = null;
        this.keybindingService = null;
        this.langService = null;
        this.route = null;
        this.router = null;
        this.rootElement = null;
        this.localizationService = null;
        this.frmI18nSettingService = null;
        this.focusInvalidService = null;
        this.componentManagerService.clear();
        this.componentManagerService = null;
        this.sanitizer = null;
        this.injector = null;
        this.enabledLanguageList = [];
    };
    BasicFormComponent.prototype.handleSizeChange = function (size) {
        this.size = size;
    };
    BasicFormComponent.prototype.onFormLoad = function () {
    };
    tslib_1.__decorate([
        ViewChild('reader_id_cd38ce3f_s96v'),
        tslib_1.__metadata("design:type", LookupGridComponent)
    ], BasicFormComponent.prototype, "reader_id_cd38ce3f_s96v", void 0);
    tslib_1.__decorate([
        ViewChild('reader_id_reader_id_name_ca4337cb_t47l'),
        tslib_1.__metadata("design:type", LookupGridComponent)
    ], BasicFormComponent.prototype, "reader_id_reader_id_name_ca4337cb_t47l", void 0);
    tslib_1.__decorate([
        ViewChild('book_id_92f531b7_4hnl'),
        tslib_1.__metadata("design:type", LookupGridComponent)
    ], BasicFormComponent.prototype, "book_id_92f531b7_4hnl", void 0);
    tslib_1.__decorate([
        ViewChild('book_id_book_id_name_54e83f87_yufc'),
        tslib_1.__metadata("design:type", LookupGridComponent)
    ], BasicFormComponent.prototype, "book_id_book_id_name_54e83f87_yufc", void 0);
    tslib_1.__decorate([
        HostBinding('class'),
        tslib_1.__metadata("design:type", Object)
    ], BasicFormComponent.prototype, "cls", void 0);
    BasicFormComponent = tslib_1.__decorate([
        Component({
            selector: 'app-basicformcomponent',
            templateUrl: './basicformcomponent.html',
            styleUrls: ['./basicformcomponent.scss'],
            providers: [
                FARRIS_DEVKIT_FRAME_PROVIDERS,
                FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS,
                { provide: FRAME_ID, useValue: 'basic-form-component' },
                { provide: BindingData, useClass: BindingData },
                { provide: Repository, useExisting: BorrowingRecordsRepository },
                LangService,
                { provide: NAMESPACE, useValue: '' },
                { provide: ServerSideToken, useClass: BefLookupRestService },
                { provide: ComboServerSideToken, useClass: DefaultComboHttpService },
                { provide: Form, useClass: BasicFormViewmodelForm },
                { provide: UIState, useClass: BasicFormViewmodelUIState },
                { provide: ViewModel, useClass: BasicFormViewmodel },
                { provide: EXCEPTION_HANDLER, useValue: null },
            ]
        }),
        tslib_1.__metadata("design:paramtypes", [WizardService,
            KeybindingService,
            LangService,
            ActivatedRoute,
            Router,
            ElementRef,
            LocalizationService,
            FrmI18nSettingService,
            FocusInvalidService,
            ComponentManagerService,
            DomSanitizer,
            Injector])
    ], BasicFormComponent);
    return BasicFormComponent;
}(FrameComponent));
export { BasicFormComponent };
