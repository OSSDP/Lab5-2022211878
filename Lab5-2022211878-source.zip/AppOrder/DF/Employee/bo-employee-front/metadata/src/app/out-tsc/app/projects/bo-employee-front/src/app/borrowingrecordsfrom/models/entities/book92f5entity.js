import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var Book92f5Entity = /** @class */ (function (_super) {
    tslib_1.__extends(Book92f5Entity, _super);
    function Book92f5Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'book_id',
            dataField: 'book_id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'book_id.book_id',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], Book92f5Entity.prototype, "book_id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'name',
            dataField: 'book_id_name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'book_id.book_id_name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], Book92f5Entity.prototype, "book_id_name", void 0);
    Book92f5Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "book_id",
            nodeCode: "book_id"
        })
    ], Book92f5Entity);
    return Book92f5Entity;
}(Entity));
export { Book92f5Entity };
