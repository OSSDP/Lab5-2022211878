import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, NgEntity } from '@farris/devkit';
import { ReaderCd38Entity } from './readercd38entity';
import { Book92f5Entity } from './book92f5entity';
var BorrowingRecordsEntity = /** @class */ (function (_super) {
    tslib_1.__extends(BorrowingRecordsEntity, _super);
    function BorrowingRecordsEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BorrowingRecordsEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], BorrowingRecordsEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'borrow_date',
            dataField: 'borrow_date',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'borrow_date',
            enableTimeZone: true,
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BorrowingRecordsEntity.prototype, "borrow_date", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'due_date',
            dataField: 'due_date',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'due_date',
            enableTimeZone: true,
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BorrowingRecordsEntity.prototype, "due_date", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'return_date',
            dataField: 'return_date',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'return_date',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], BorrowingRecordsEntity.prototype, "return_date", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'rstatus',
            dataField: 'rstatus',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: '1',
            path: 'rstatus',
        }),
        tslib_1.__metadata("design:type", Object)
    ], BorrowingRecordsEntity.prototype, "rstatus", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'notes',
            dataField: 'notes',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'notes',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BorrowingRecordsEntity.prototype, "notes", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'reader_id',
            originalDataField: 'reader_id',
            type: ReaderCd38Entity
        }),
        tslib_1.__metadata("design:type", ReaderCd38Entity)
    ], BorrowingRecordsEntity.prototype, "reader_id", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'book_id',
            originalDataField: 'book_id',
            type: Book92f5Entity
        }),
        tslib_1.__metadata("design:type", Book92f5Entity)
    ], BorrowingRecordsEntity.prototype, "book_id", void 0);
    BorrowingRecordsEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "BorrowingRecords",
            nodeCode: "borrowingRecordss"
        })
    ], BorrowingRecordsEntity);
    return BorrowingRecordsEntity;
}(Entity));
export { BorrowingRecordsEntity };
