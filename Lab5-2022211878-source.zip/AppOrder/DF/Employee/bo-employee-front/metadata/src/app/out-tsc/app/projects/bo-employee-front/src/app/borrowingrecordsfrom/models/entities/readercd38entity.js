import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var ReaderCd38Entity = /** @class */ (function (_super) {
    tslib_1.__extends(ReaderCd38Entity, _super);
    function ReaderCd38Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'reader_id',
            dataField: 'reader_id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'reader_id.reader_id',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ReaderCd38Entity.prototype, "reader_id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'name',
            dataField: 'reader_id_name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'reader_id.reader_id_name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ReaderCd38Entity.prototype, "reader_id_name", void 0);
    ReaderCd38Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "reader_id",
            nodeCode: "reader_id"
        })
    ], ReaderCd38Entity);
    return ReaderCd38Entity;
}(Entity));
export { ReaderCd38Entity };
