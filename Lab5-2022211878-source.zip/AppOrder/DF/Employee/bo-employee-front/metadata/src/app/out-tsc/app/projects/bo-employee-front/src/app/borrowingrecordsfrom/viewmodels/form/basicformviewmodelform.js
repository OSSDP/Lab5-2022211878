import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'version_7562dd01_rjne',
            name: "{{version_7562dd01_rjne}}",
            binding: 'version',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '版本',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "version", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'reader_id_cd38ce3f_s96v',
            name: "{{reader_id_cd38ce3f_s96v}}",
            binding: 'reader_id.reader_id',
            updateOn: 'blur',
            defaultI18nValue: '借阅者ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "reader_id", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'reader_id_reader_id_name_ca4337cb_t47l',
            name: "{{reader_id_reader_id_name_ca4337cb_t47l}}",
            binding: 'reader_id.reader_id_name',
            updateOn: 'blur',
            defaultI18nValue: '姓名',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "reader_id_reader_id_name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'book_id_92f531b7_4hnl',
            name: "{{book_id_92f531b7_4hnl}}",
            binding: 'book_id.book_id',
            updateOn: 'blur',
            defaultI18nValue: '数据ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "book_id", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'book_id_book_id_name_54e83f87_yufc',
            name: "{{book_id_book_id_name_54e83f87_yufc}}",
            binding: 'book_id.book_id_name',
            updateOn: 'blur',
            defaultI18nValue: '书名',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "book_id_book_id_name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'borrow_date_65e8e886_bmex',
            name: "{{borrow_date_65e8e886_bmex}}",
            binding: 'borrow_date',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '借阅时间',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "borrow_date", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'due_date_b0270f3d_wrh1',
            name: "{{due_date_b0270f3d_wrh1}}",
            binding: 'due_date',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '应还日期',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "due_date", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'return_date_ff65912b_izvj',
            name: "{{return_date_ff65912b_izvj}}",
            binding: 'return_date',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '归还日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "return_date", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'rstatus_3d04cde5_waeb',
            name: "{{rstatus_3d04cde5_waeb}}",
            binding: 'rstatus',
            updateOn: 'change',
            defaultI18nValue: '状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "rstatus", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'notes_494b4a5e_5w9n',
            name: "{{notes_494b4a5e_5w9n}}",
            binding: 'notes',
            updateOn: 'blur',
            defaultI18nValue: '备注',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "notes", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '借阅记录',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
