import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { BorrowingRecordsEntity } from './entities/borrowingrecordsentity';
import { BorrowingRecordsProxy } from './borrowingrecordsproxy';
var BorrowingRecordsRepository = /** @class */ (function (_super) {
    tslib_1.__extends(BorrowingRecordsRepository, _super);
    function BorrowingRecordsRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'BorrowingRecordsRepository';
        _this.paginationInfo = {
            BorrowingRecordsEntity: {
                pageSize: 20,
            }
        };
        _this.proxy = injector.get(BorrowingRecordsProxy, null);
        return _this;
    }
    BorrowingRecordsRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/apporder/df/v1.0/borrowingrecordslist_frm',
            entityType: BorrowingRecordsEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], BorrowingRecordsRepository);
    return BorrowingRecordsRepository;
}(BefRepository));
export { BorrowingRecordsRepository };
