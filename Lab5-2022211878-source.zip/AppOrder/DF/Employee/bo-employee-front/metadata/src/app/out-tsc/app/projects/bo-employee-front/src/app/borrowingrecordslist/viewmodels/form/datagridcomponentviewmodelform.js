import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'reader_id.reader_id',
            name: "{{reader_id_cd38ce3f_994g}}",
            binding: 'reader_id.reader_id',
            updateOn: 'blur',
            defaultI18nValue: '借阅者ID',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "reader_id", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'reader_id.reader_id_name',
            name: "{{reader_id_reader_id_name_7e7ecb28_3u3c}}",
            binding: 'reader_id.reader_id_name',
            updateOn: 'blur',
            defaultI18nValue: '姓名',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "reader_id_reader_id_name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'book_id.book_id',
            name: "{{book_id_92f531b7_eek8}}",
            binding: 'book_id.book_id',
            updateOn: 'blur',
            defaultI18nValue: '数据ID',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "book_id", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'book_id.book_id_name',
            name: "{{book_id_book_id_name_3754e752_tox3}}",
            binding: 'book_id.book_id_name',
            updateOn: 'blur',
            defaultI18nValue: '书名',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "book_id_book_id_name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'borrow_date',
            name: "{{borrow_date_65ae19c2_9eah}}",
            binding: 'borrow_date',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '借阅时间',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "borrow_date", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'due_date',
            name: "{{due_date_353e56f6_041e}}",
            binding: 'due_date',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '应还日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "due_date", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'return_date',
            name: "{{return_date_e41c3e1a_iu6u}}",
            binding: 'return_date',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '归还日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "return_date", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'rstatus',
            name: "{{rstatus_f0c51e4e_3exz}}",
            binding: 'rstatus',
            updateOn: 'change',
            defaultI18nValue: '状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "rstatus", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'notes',
            name: "{{notes_bf15a201_kfpv}}",
            binding: 'notes',
            updateOn: 'blur',
            defaultI18nValue: '备注',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "notes", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '借阅记录',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
