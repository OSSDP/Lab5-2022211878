import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var PhoneNumberC6e8Entity = /** @class */ (function (_super) {
    tslib_1.__extends(PhoneNumberC6e8Entity, _super);
    function PhoneNumberC6e8Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'PhoneNumber',
            dataField: 'phoneNumber',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'phone.PhoneNumber',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], PhoneNumberC6e8Entity.prototype, "phoneNumber", void 0);
    PhoneNumberC6e8Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "phone",
            nodeCode: "phone"
        })
    ], PhoneNumberC6e8Entity);
    return PhoneNumberC6e8Entity;
}(Entity));
export { PhoneNumberC6e8Entity };
