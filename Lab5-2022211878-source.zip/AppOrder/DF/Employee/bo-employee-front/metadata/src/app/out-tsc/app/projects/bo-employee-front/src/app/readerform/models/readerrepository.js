import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { ReaderEntity } from './entities/readerentity';
import { ReaderProxy } from './readerproxy';
var ReaderRepository = /** @class */ (function (_super) {
    tslib_1.__extends(ReaderRepository, _super);
    function ReaderRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'ReaderRepository';
        _this.paginationInfo = {};
        _this.proxy = injector.get(ReaderProxy, null);
        return _this;
    }
    ReaderRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/apporder/df/v1.0/readerform_frm',
            entityType: ReaderEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], ReaderRepository);
    return ReaderRepository;
}(BefRepository));
export { ReaderRepository };
