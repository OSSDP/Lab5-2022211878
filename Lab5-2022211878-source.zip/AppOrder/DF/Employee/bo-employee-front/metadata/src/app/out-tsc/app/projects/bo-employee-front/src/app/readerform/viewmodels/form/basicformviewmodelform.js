import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'name_35962ea3_vli6',
            name: "{{name_35962ea3_vli6}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '姓名',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'phone_PhoneNumber_c6e8062a_syff',
            name: "{{phone_PhoneNumber_c6e8062a_syff}}",
            binding: 'phone.phoneNumber',
            updateOn: 'blur',
            defaultI18nValue: '手机电话号码',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "phone_PhoneNumber", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'password_4cf5f27e_pmhe',
            name: "{{password_4cf5f27e_pmhe}}",
            binding: 'password',
            updateOn: 'blur',
            defaultI18nValue: '密码',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "password", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'id_f72e08a6_agux',
            name: "{{id_f72e08a6_agux}}",
            binding: 'id',
            updateOn: 'blur',
            defaultI18nValue: '主键',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "id", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'rstatus_336df55a_ltrw',
            name: "{{rstatus_336df55a_ltrw}}",
            binding: 'rstatus',
            updateOn: 'change',
            defaultI18nValue: '状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "rstatus", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '读者',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
