import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var PhoneNumberD254Entity = /** @class */ (function (_super) {
    tslib_1.__extends(PhoneNumberD254Entity, _super);
    function PhoneNumberD254Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'PhoneNumber',
            dataField: 'phoneNumber',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'phone.PhoneNumber',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], PhoneNumberD254Entity.prototype, "phoneNumber", void 0);
    PhoneNumberD254Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "phone",
            nodeCode: "phone"
        })
    ], PhoneNumberD254Entity);
    return PhoneNumberD254Entity;
}(Entity));
export { PhoneNumberD254Entity };
