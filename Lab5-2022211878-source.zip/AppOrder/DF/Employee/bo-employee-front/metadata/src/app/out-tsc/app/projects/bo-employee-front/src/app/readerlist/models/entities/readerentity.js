import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, NgEntity } from '@farris/devkit';
import { PhoneNumberD254Entity } from './phonenumberd254entity';
var ReaderEntity = /** @class */ (function (_super) {
    tslib_1.__extends(ReaderEntity, _super);
    function ReaderEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ReaderEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], ReaderEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'name',
            dataField: 'name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'name',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ReaderEntity.prototype, "name", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'rstatus',
            dataField: 'rstatus',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: '1',
            path: 'rstatus',
        }),
        tslib_1.__metadata("design:type", Object)
    ], ReaderEntity.prototype, "rstatus", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'password',
            dataField: 'password',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'password',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ReaderEntity.prototype, "password", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'phone',
            originalDataField: 'phone',
            type: PhoneNumberD254Entity
        }),
        tslib_1.__metadata("design:type", PhoneNumberD254Entity)
    ], ReaderEntity.prototype, "phone", void 0);
    ReaderEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "Reader",
            nodeCode: "readers"
        })
    ], ReaderEntity);
    return ReaderEntity;
}(Entity));
export { ReaderEntity };
