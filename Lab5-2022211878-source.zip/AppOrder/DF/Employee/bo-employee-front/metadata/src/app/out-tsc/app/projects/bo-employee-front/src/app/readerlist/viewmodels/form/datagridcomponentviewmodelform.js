import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'id',
            name: "{{id_101f9ae3_ymt5}}",
            binding: 'id',
            updateOn: 'blur',
            defaultI18nValue: '主键',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "id", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'version',
            name: "{{version_a3b0f27e_kxfu}}",
            binding: 'version',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '版本',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "version", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'name',
            name: "{{name_6787d2f4_equp}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '姓名',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'phone.phoneNumber',
            name: "{{phone_PhoneNumber_d25442de_u057}}",
            binding: 'phone.phoneNumber',
            updateOn: 'blur',
            defaultI18nValue: '手机电话号码',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "phone_PhoneNumber", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'rstatus',
            name: "{{rstatus_d1ddfc33_pzhz}}",
            binding: 'rstatus',
            updateOn: 'change',
            defaultI18nValue: '状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "rstatus", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'password',
            name: "{{password_3262a83e_zz1z}}",
            binding: 'password',
            updateOn: 'blur',
            defaultI18nValue: '密码',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "password", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '读者',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
