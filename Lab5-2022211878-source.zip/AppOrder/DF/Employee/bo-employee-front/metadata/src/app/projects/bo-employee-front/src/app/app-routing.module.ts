import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
const routes: Routes = [
  { path: 'BookList', loadChildren:'./booklist/booklist#BookListModule'},
  { path: 'BookForm', loadChildren:'./bookform/bookform#BookFormModule'},
  { path: 'ReaderForm', loadChildren:'./readerform/readerform#ReaderFormModule'},
  { path: 'ReaderList', loadChildren:'./readerlist/readerlist#ReaderListModule'},
  { path: 'BorrowingRecordsList', loadChildren:'./borrowingrecordslist/borrowingrecordslist#BorrowingRecordsListModule'},
  { path: 'BorrowingRecordsFrom', loadChildren:'./borrowingrecordsfrom/borrowingrecordsfrom#BorrowingRecordsFromModule'}
];
@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true })],
    exports: [RouterModule]
})
export class AppRoutingModule { }